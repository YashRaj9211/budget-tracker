package router_test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"splitwise-go/models"
	"splitwise-go/router"
	"splitwise-go/testutil"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type api struct {
	t      *testing.T
	engine *gin.Engine
	db     *gorm.DB
}

type user struct {
	ID    string
	Token string
}

func newAPI(t *testing.T) *api {
	t.Helper()
	db := testutil.NewDB(t, true)
	t.Setenv("JWT_SECRET", "test-secret")
	gin.SetMode(gin.TestMode)
	e := gin.New()
	router.DefaultRouter(&e.RouterGroup)
	return &api{t: t, engine: e, db: db}
}

// call sends a JSON request and returns the status and decoded body (map, slice or nil).
func (a *api) call(method, path, token string, body any) (int, any) {
	a.t.Helper()
	var buf bytes.Buffer
	if body != nil {
		if err := json.NewEncoder(&buf).Encode(body); err != nil {
			a.t.Fatal(err)
		}
	}
	req := httptest.NewRequest(method, "/api/_private/v1"+path, &buf)
	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		req.Header.Set("x-token", token)
	}
	w := httptest.NewRecorder()
	a.engine.ServeHTTP(w, req)
	var out any
	_ = json.Unmarshal(w.Body.Bytes(), &out)
	return w.Code, out
}

func (a *api) signup(name string) user {
	a.t.Helper()
	pub := func(path string, body any) (int, map[string]any) {
		var buf bytes.Buffer
		_ = json.NewEncoder(&buf).Encode(body)
		req := httptest.NewRequest(http.MethodPost, "/api/_public/v1/users/"+path, &buf)
		req.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		a.engine.ServeHTTP(w, req)
		var out map[string]any
		_ = json.Unmarshal(w.Body.Bytes(), &out)
		return w.Code, out
	}
	email := name + "@example.com"
	if code, out := pub("signup", map[string]any{"email": email, "name": name, "username": name, "password": "password123"}); code != 200 {
		a.t.Fatalf("signup %s: %d %v", name, code, out)
	}
	code, out := pub("login", map[string]any{"email": email, "password": "password123"})
	if code != 200 {
		a.t.Fatalf("login %s: %d %v", name, code, out)
	}
	return user{ID: out["user"].(map[string]any)["id"].(string), Token: out["token"].(string)}
}

func (a *api) befriend(x, y user) {
	a.t.Helper()
	if err := a.db.Create(&models.Friendship{UserID: x.ID, FriendID: y.ID, Status: "ACCEPTED"}).Error; err != nil {
		a.t.Fatal(err)
	}
}

func (a *api) expect(label string, want, got int) {
	a.t.Helper()
	if want != got {
		a.t.Errorf("%s: want HTTP %d, got %d", label, want, got)
	}
}

func asMap(v any) map[string]any { m, _ := v.(map[string]any); return m }
func asList(v any) []any         { l, _ := v.([]any); return l }

func split(userID, amount string) map[string]any {
	return map[string]any{"userId": userID, "amount": amount, "splitType": "EQUAL"}
}

func TestAuthentication(t *testing.T) {
	a := newAPI(t)
	for _, p := range []string{"/expenses", "/groups", "/dashboard", "/split/overview", "/friends"} {
		code, _ := a.call("GET", p, "", nil)
		a.expect("no token "+p, 401, code)
	}
	alice := a.signup("alice")
	code, _ := a.call("GET", "/expenses/user/"+alice.ID, alice.Token, nil)
	a.expect("removed /expenses/user/:id route", 404, code)

	// "Authorization: Bearer <token>" must work too (Bruno / Swagger use it)
	req := httptest.NewRequest("GET", "/api/_private/v1/expenses", nil)
	req.Header.Set("Authorization", "Bearer "+alice.Token)
	w := httptest.NewRecorder()
	a.engine.ServeHTTP(w, req)
	a.expect("bearer header", 200, w.Code)
}

func TestExpenseAuthorizationAndValidation(t *testing.T) {
	a := newAPI(t)
	alice, bob, carol := a.signup("alice"), a.signup("bob"), a.signup("carol")
	a.befriend(alice, bob) // carol is nobody's friend

	// Personal expenses are private.
	code, out := a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "500", "description": "secret", "type": "PERSONAL"})
	a.expect("create personal", 201, code)
	personalID := asMap(out)["id"].(string)
	_, list := a.call("GET", "/expenses", bob.Token, nil)
	if len(asList(list)) != 0 {
		t.Errorf("bob can see alice's expenses: %v", list)
	}
	code, _ = a.call("DELETE", "/expenses/"+personalID, bob.Token, nil)
	a.expect("bob deletes alice's personal expense", 403, code)
	code, _ = a.call("PUT", "/expenses/"+personalID, bob.Token, map[string]any{"amount": "1", "description": "x", "type": "PERSONAL"})
	a.expect("bob edits alice's personal expense", 403, code)

	// Validation.
	bad := []struct {
		name string
		body map[string]any
	}{
		{"negative amount", map[string]any{"amount": "-50", "description": "x", "type": "PERSONAL"}},
		{"zero amount", map[string]any{"amount": "0", "description": "x", "type": "PERSONAL"}},
		{"empty description", map[string]any{"amount": "5", "description": "  ", "type": "PERSONAL"}},
		{"unknown type", map[string]any{"amount": "5", "description": "x", "type": "GIFT"}},
		{"huge amount", map[string]any{"amount": "99999999999999", "description": "x", "type": "PERSONAL"}},
		{"split without splits", map[string]any{"amount": "100", "description": "x", "type": "SPLIT"}},
		{"splits do not add up", map[string]any{"amount": "100", "description": "x", "type": "SPLIT", "splits": []any{split(bob.ID, "10")}}},
		{"duplicate split users", map[string]any{"amount": "100", "description": "x", "type": "SPLIT", "splits": []any{split(bob.ID, "50"), split(bob.ID, "50")}}},
		{"negative split", map[string]any{"amount": "100", "description": "x", "type": "SPLIT", "splits": []any{split(bob.ID, "150"), split(alice.ID, "-50")}}},
		{"bad split type", map[string]any{"amount": "100", "description": "x", "type": "SPLIT", "splits": []any{map[string]any{"userId": bob.ID, "amount": "100", "splitType": "MAGIC"}}}},
	}
	for _, tc := range bad {
		code, _ := a.call("POST", "/expenses", alice.Token, tc.body)
		a.expect(tc.name, 400, code)
	}

	// Splitting outside a group needs an accepted friendship.
	code, _ = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "5000", "description": "you owe me", "type": "SPLIT", "splits": []any{split(carol.ID, "5000")}})
	a.expect("charge a non-friend", 403, code)
	code, _ = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "100", "description": "dinner", "type": "SPLIT", "splits": []any{split(alice.ID, "50"), split(bob.ID, "50")}})
	a.expect("split with a friend", 201, code)

	// A payer other than the caller is not allowed outside a group.
	code, _ = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "10", "description": "x", "type": "PERSONAL", "userId": bob.ID})
	a.expect("impersonate payer outside group", 403, code)

	// Nested objects in the JSON must not create records.
	var usersBefore int64
	a.db.Model(&models.User{}).Count(&usersBefore)
	a.call("POST", "/expenses", alice.Token, map[string]any{
		"amount": "5", "description": "x", "type": "PERSONAL",
		"user": map[string]any{"id": "evil", "email": "evil@x.com", "name": "E", "username": "evil", "password": "x"},
	})
	var usersAfter int64
	a.db.Model(&models.User{}).Count(&usersAfter)
	if usersBefore != usersAfter {
		t.Errorf("a nested user object created a user (%d -> %d)", usersBefore, usersAfter)
	}

	// isSettlement only applies to SPLIT expenses.
	_, out = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "5", "description": "x", "type": "PERSONAL", "isSettlement": true})
	if asMap(out)["isSettlement"] != false {
		t.Errorf("PERSONAL expense kept isSettlement=true: %v", out)
	}
	_, out = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "20", "description": "Settlement: bob paid alice", "type": "SPLIT", "isSettlement": true, "splits": []any{split(alice.ID, "20")}})
	if asMap(out)["isSettlement"] != true {
		t.Errorf("settlement flag not stored: %v", out)
	}

	// Settling: only your own share.
	_, out = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "100", "description": "trip", "type": "SPLIT", "splits": []any{split(alice.ID, "50"), split(bob.ID, "50")}})
	var bobSplitID string
	for _, s := range asList(asMap(out)["splits"]) {
		if asMap(s)["userId"] == bob.ID {
			bobSplitID = asMap(s)["id"].(string)
		}
	}
	code, _ = a.call("PUT", "/expenses/settle/"+bobSplitID, alice.Token, nil)
	a.expect("alice settles bob's share", 404, code)
	code, _ = a.call("PUT", "/expenses/settle/"+bobSplitID, bob.Token, nil)
	a.expect("bob settles his own share", 200, code)
}

func TestGroupRules(t *testing.T) {
	a := newAPI(t)
	alice, bob, carol := a.signup("alice"), a.signup("bob"), a.signup("carol")
	a.befriend(alice, bob)

	code, _ := a.call("POST", "/groups", alice.Token, map[string]any{"name": "Trip", "description": "d", "simplifyDebts": false, "memberIds": []string{carol.ID}})
	a.expect("create group with a non-friend", 400, code)
	code, _ = a.call("POST", "/groups", alice.Token, map[string]any{"name": "Trip", "description": "d", "simplifyDebts": false, "memberIds": []string{"no-such-user"}})
	a.expect("create group with an unknown user", 400, code)
	var groupsAfterFailures int64
	a.db.Model(&models.Group{}).Count(&groupsAfterFailures)
	if groupsAfterFailures != 0 {
		t.Errorf("failed group creation left %d groups behind", groupsAfterFailures)
	}

	code, out := a.call("POST", "/groups", alice.Token, map[string]any{"name": "Trip", "description": "d", "simplifyDebts": false, "memberIds": []string{bob.ID}})
	a.expect("create group with a friend", 200, code)
	gid := asMap(out)["id"].(string)
	if n := len(asList(asMap(out)["members"])); n != 2 {
		t.Errorf("want 2 members, got %d", n)
	}

	// Outsider (carol) cannot read or write.
	for _, tc := range []struct{ method, path string }{
		{"GET", "/groups/" + gid}, {"GET", "/groups/" + gid + "/members"},
		{"PUT", "/groups/" + gid + "/toggle-simplify"}, {"DELETE", "/groups/" + gid},
		{"POST", "/groups/" + gid + "/members/" + carol.ID},
	} {
		code, _ := a.call(tc.method, tc.path, carol.Token, nil)
		a.expect("outsider "+tc.method+" "+tc.path, 403, code)
	}
	code, _ = a.call("POST", "/expenses", carol.Token, map[string]any{"amount": "90", "description": "spam", "type": "SPLIT", "groupId": gid, "splits": []any{split(carol.ID, "90")}})
	a.expect("outsider creates expense in group", 403, code)

	// Members can record expenses, but only with other members.
	code, _ = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "100", "description": "x", "type": "SPLIT", "groupId": gid, "splits": []any{split(alice.ID, "50"), split(carol.ID, "50")}})
	a.expect("charge a non-member inside group", 400, code)
	code, out = a.call("POST", "/expenses", alice.Token, map[string]any{"amount": "100", "description": "hotel", "type": "SPLIT", "groupId": gid, "userId": bob.ID, "splits": []any{split(alice.ID, "50"), split(bob.ID, "50")}})
	a.expect("bob recorded as payer by alice", 201, code)
	expID := asMap(out)["id"].(string)
	if asMap(out)["userId"] != bob.ID {
		t.Errorf("payer should be bob, got %v", asMap(out)["userId"])
	}
	code, _ = a.call("DELETE", "/expenses/"+expID, carol.Token, nil)
	a.expect("outsider deletes group expense", 403, code)

	// Overview returns groups + expenses in one response, only for members.
	_, out = a.call("GET", "/split/overview", bob.Token, nil)
	if len(asList(asMap(out)["groups"])) != 1 || len(asList(asMap(out)["expenses"])) != 1 {
		t.Errorf("bob's overview wrong: %v", out)
	}
	_, out = a.call("GET", "/split/overview", carol.Token, nil)
	if len(asList(asMap(out)["groups"])) != 0 || len(asList(asMap(out)["expenses"])) != 0 {
		t.Errorf("carol's overview should be empty: %v", out)
	}

	// Adding members: friends only; no duplicates.
	code, _ = a.call("POST", "/groups/"+gid+"/members/"+carol.ID, alice.Token, nil)
	a.expect("add a non-friend", 403, code)
	code, _ = a.call("POST", "/groups/"+gid+"/members/"+bob.ID, alice.Token, nil)
	a.expect("add an existing member", 400, code)

	// Admin rules.
	code, _ = a.call("DELETE", "/groups/"+gid+"/members/"+alice.ID, alice.Token, nil)
	a.expect("remove the last admin", 400, code)
	code, _ = a.call("DELETE", "/groups/"+gid+"/members/"+alice.ID, bob.Token, nil)
	a.expect("non-admin removes someone", 403, code)
	code, _ = a.call("DELETE", "/groups/"+gid+"/leave", carol.Token, nil)
	a.expect("non-member leaves", 404, code)

	// Bob owes alice nothing net? hotel paid by bob, split 50/50 -> alice owes bob 50, so
	// alice must settle before leaving.
	code, _ = a.call("DELETE", "/groups/"+gid+"/leave", alice.Token, nil)
	a.expect("leave with unsettled debt", 400, code)
	code, _ = a.call("DELETE", "/expenses/"+expID, bob.Token, nil)
	a.expect("bob deletes the group expense", 200, code)

	// Last admin leaves: bob is promoted automatically.
	code, _ = a.call("DELETE", "/groups/"+gid+"/leave", alice.Token, nil)
	a.expect("last admin leaves", 200, code)
	var bobMember models.GroupMember
	if err := a.db.Where("group_id = ? AND user_id = ?", gid, bob.ID).First(&bobMember).Error; err != nil {
		t.Fatal(err)
	}
	if bobMember.Role != "ADMIN" {
		t.Errorf("bob should have been promoted to ADMIN, is %q", bobMember.Role)
	}
	code, _ = a.call("DELETE", "/groups/"+gid, bob.Token, nil)
	a.expect("new admin deletes group", 200, code)
	_ = fmt.Sprint()
}
